To compile run: gcc --std=gnu99 -o smallsh royal_program3.c
To run the executable: ./smallsh
To run the test script: ./p3testscript 2>&1