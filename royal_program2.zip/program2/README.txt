to compile: gcc -g --std=gnu99 -o movies_by_year royal_program2.c
this creates the executable movies
to run: ./movies_by_year
