to compile: gcc -g --std=gnu99 -o movies royal_program1.c
this creates the executable movies
to run: ./movies file_name.csv
